import greengrasssdk
import serial

SERIAL_PORT = '/dev/ttyUSB0'

SERIAL_RATE = 9600

client = greengrasssdk.client('iot-data')

topicA = "topic/Serial"

def greengrass_serial_stream_run():
    ser = serial.Serial(SERIAL_PORT, SERIAL_RATE)
    while True:
        reading = ser.readline().decode('utf-8').replace('\n','')

        reading = reading.rstrip()
        strs = str(reading)
        
        client.publish(topic=topicA, payload=strs)
        

greengrass_serial_stream_run()

def function_handler(event, context):
    return
