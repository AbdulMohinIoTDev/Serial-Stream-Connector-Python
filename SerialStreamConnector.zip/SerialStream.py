import greengrasssdk
import serial

SERIAL_PORT = '/dev/ttyUSB0'

SERIAL_RATE = 9600

client = greengrasssdk.client('iot-data')

topicA = "topic/traceJson"

def greengrass_serial_stream_run():
    ser = serial.Serial(SERIAL_PORT, SERIAL_RATE)
    while True:
        reading = ser.readline().decode('utf-8').replace('\n','')

    	if reading == "PS":
            topicA = "topic/PollingStatus"
            continue
                	
    	if reading == "AA":
            topicA = "topic/ActiveAlarms"
            continue
        
        if reading == "AT":
            topicA = "topic/AlarmTable"
            continue

        if reading == "ET":
            topicA = "topic/EventTable"
            continue

        reading = reading.rstrip()
        strs = str(reading)
        strs = "["+strs+"]"
        
        client.publish(topic=topicA, payload=strs)
        

greengrass_serial_stream_run()

def function_handler(event, context):
    return
